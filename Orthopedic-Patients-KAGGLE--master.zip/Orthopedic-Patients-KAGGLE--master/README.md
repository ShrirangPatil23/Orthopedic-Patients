# Orthopedic-Patients
Biomedical features of Orthopedic Patients.
This is a ML prediction model for the Biomechanical features if Orthopedic Patients Dataset.
Depending on 6 attributes it classifies the patients into 3 classes i.e. Spondylolisthesis, Hernia and Normal.
The model uses Gaussian Naive Bayes for classification and currently has an accuracy of 88% (approx).
